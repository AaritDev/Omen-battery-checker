# OMEN Battery Monitor

A beautiful, translucent battery monitor for HP OMEN 16 on Linux (Fedora/KDE Plasma).

## What it does

- **System tray icon** with live battery % and AC/battery indicator
- **Click to open** a translucent dark panel showing:
  - Animated arc gauge with your charge limit marked
  - Power source bar (AC vs battery + watts)
  - Energy now / full / design capacity (Wh)
  - BIOS-enforced cap %, cycle count, time remaining, voltage
- **80% limit with notifications**: KDE desktop notification (urgent) when
  you should unplug
- **Top Up button**: suppresses the 80% alert for one full cycle,
  notifies you when you hit 100% instead

## Why notifications instead of auto-cutting power

HP OMEN 16-xd0 has no kernel charge threshold API (`charge_control_end_threshold`
doesn't exist in sysfs). The BIOS "Adaptive Battery Optimizer" setting is cosmetic
on this model. This is a known HP limitation confirmed across multiple OMEN 16
models and kernel versions up to 6.18.

The notification approach is exactly what Al Dente uses on unsupported Macs.

## Install

```bash
# Install dependencies
sudo dnf install python3-pyqt6 libnotify

# Put the script somewhere permanent
mkdir -p ~/omen-battery
cp omen_battery.py ~/omen-battery/

# Autostart: edit the .desktop file to set your actual home path
sed -i "s|/home/USER|$HOME|g" omen_battery.desktop
cp omen_battery.desktop ~/.config/autostart/

# Run it now
python3 ~/omen-battery/omen_battery.py &
```

## Changing the limit

Edit the state file at `~/.local/share/omen-battery/state.json`:
```json
{"limit": 80, "top_up_active": false, "notified_at": -1}
```
Change `"limit"` to whatever % you want (e.g. 75, 80, 85).
The app picks it up on the next poll (every 8 seconds for the panel, 15s for the tray).

## If kernel support lands

If a future kernel adds `charge_control_end_threshold` for your OMEN,
replace the notification logic in `_refresh()` with a sysfs write.
The rest of the UI stays the same.
